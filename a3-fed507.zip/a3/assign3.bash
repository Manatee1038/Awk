#!/bin/bash

awk -F, -f assign3.awk $@;
